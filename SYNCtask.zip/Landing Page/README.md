# First Deploy - AzureDeploy
URL - https://thankful-rock-0cb96d210.2.azurestaticapps.net/
