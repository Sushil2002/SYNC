# music-player-app


### song on the app
- Rush by Ayra Starr
- Sofri by Fireboy DML
- Girlfriend by Ruger
- Loving you by Zinoleesky
- Rocking by Zinoleesky
